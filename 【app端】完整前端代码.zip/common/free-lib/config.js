export default {
    // #ifndef H5
    baseUrl:"http://wechat.dishait.cn",
    // #endif
	
    // #ifdef H5
    baseUrl:"/api",
    // #endif
    socketUrl:"ws://wechat.dishait.cn/ws",
	
    env:"dev",
	
	codeUrl:"http://wechat.dishait.cn",
	
	// 表情包线上路径
	emoticonUrl:"http://wechath5.dishait.cn/static/images/emoticon/5497/"
}