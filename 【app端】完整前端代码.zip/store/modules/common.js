export default {
	state:{
		KeyboardHeight:0
	},
	mutations:{
		changeKeyboardHeight(state,h){
			state.KeyboardHeight = h
		}
	}
}