<template>
	<view style="height: 18rpx;background-color: #EFEDE9;"></view>
</template>

<script>
</script>

<style>
</style>
