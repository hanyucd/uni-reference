export default {
	state:{
		keyboardHeight:0
	},
	mutations:{
		changeKeyboardHeight(state,h){
			state.keyboardHeight = h
		}
	}
}